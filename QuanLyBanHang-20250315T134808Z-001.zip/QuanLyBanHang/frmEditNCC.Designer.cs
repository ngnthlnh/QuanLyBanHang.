﻿namespace QuanLyBanHang
{
    partial class frmEditNCC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lbDiaChi = new System.Windows.Forms.Label();
            this.txtTenNGH = new System.Windows.Forms.TextBox();
            this.lbTenNGH = new System.Windows.Forms.Label();
            this.txtTenNCC = new System.Windows.Forms.TextBox();
            this.lbMaThue = new System.Windows.Forms.Label();
            this.txtMaThue = new System.Windows.Forms.TextBox();
            this.txtSTK = new System.Windows.Forms.TextBox();
            this.lbSTK = new System.Windows.Forms.Label();
            this.lbTenNCC = new System.Windows.Forms.Label();
            this.txtMaNCC = new System.Windows.Forms.TextBox();
            this.lbMaNCC = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bnSave = new System.Windows.Forms.Button();
            this.bnCancel = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtDiaChi);
            this.panel1.Controls.Add(this.lbDiaChi);
            this.panel1.Controls.Add(this.txtTenNGH);
            this.panel1.Controls.Add(this.lbTenNGH);
            this.panel1.Controls.Add(this.txtTenNCC);
            this.panel1.Controls.Add(this.lbMaThue);
            this.panel1.Controls.Add(this.txtMaThue);
            this.panel1.Controls.Add(this.txtSTK);
            this.panel1.Controls.Add(this.lbSTK);
            this.panel1.Controls.Add(this.lbTenNCC);
            this.panel1.Controls.Add(this.txtMaNCC);
            this.panel1.Controls.Add(this.lbMaNCC);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 449);
            this.panel1.TabIndex = 3;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(508, 255);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(126, 26);
            this.txtDiaChi.TabIndex = 15;
            // 
            // lbDiaChi
            // 
            this.lbDiaChi.AutoSize = true;
            this.lbDiaChi.Location = new System.Drawing.Point(504, 218);
            this.lbDiaChi.Name = "lbDiaChi";
            this.lbDiaChi.Size = new System.Drawing.Size(57, 20);
            this.lbDiaChi.TabIndex = 14;
            this.lbDiaChi.Text = "Địa chỉ";
            // 
            // txtTenNGH
            // 
            this.txtTenNGH.Location = new System.Drawing.Point(234, 255);
            this.txtTenNGH.Name = "txtTenNGH";
            this.txtTenNGH.Size = new System.Drawing.Size(217, 26);
            this.txtTenNGH.TabIndex = 13;
            // 
            // lbTenNGH
            // 
            this.lbTenNGH.AutoSize = true;
            this.lbTenNGH.Location = new System.Drawing.Point(230, 218);
            this.lbTenNGH.Name = "lbTenNGH";
            this.lbTenNGH.Size = new System.Drawing.Size(153, 20);
            this.lbTenNGH.TabIndex = 12;
            this.lbTenNGH.Text = "Tên người giao hàng";
            // 
            // txtTenNCC
            // 
            this.txtTenNCC.Location = new System.Drawing.Point(234, 82);
            this.txtTenNCC.Name = "txtTenNCC";
            this.txtTenNCC.Size = new System.Drawing.Size(217, 26);
            this.txtTenNCC.TabIndex = 11;
            // 
            // lbMaThue
            // 
            this.lbMaThue.AutoSize = true;
            this.lbMaThue.Location = new System.Drawing.Point(36, 218);
            this.lbMaThue.Name = "lbMaThue";
            this.lbMaThue.Size = new System.Drawing.Size(88, 20);
            this.lbMaThue.TabIndex = 10;
            this.lbMaThue.Text = "Mã số thuể";
            // 
            // txtMaThue
            // 
            this.txtMaThue.Location = new System.Drawing.Point(40, 255);
            this.txtMaThue.Name = "txtMaThue";
            this.txtMaThue.Size = new System.Drawing.Size(126, 26);
            this.txtMaThue.TabIndex = 7;
            // 
            // txtSTK
            // 
            this.txtSTK.Location = new System.Drawing.Point(508, 82);
            this.txtSTK.Name = "txtSTK";
            this.txtSTK.Size = new System.Drawing.Size(126, 26);
            this.txtSTK.TabIndex = 6;
            // 
            // lbSTK
            // 
            this.lbSTK.AutoSize = true;
            this.lbSTK.Location = new System.Drawing.Point(506, 45);
            this.lbSTK.Name = "lbSTK";
            this.lbSTK.Size = new System.Drawing.Size(98, 20);
            this.lbSTK.TabIndex = 5;
            this.lbSTK.Text = "Số tài khoản";
            // 
            // lbTenNCC
            // 
            this.lbTenNCC.AutoSize = true;
            this.lbTenNCC.Location = new System.Drawing.Point(230, 45);
            this.lbTenNCC.Name = "lbTenNCC";
            this.lbTenNCC.Size = new System.Drawing.Size(136, 20);
            this.lbTenNCC.TabIndex = 3;
            this.lbTenNCC.Text = "Tên nhà cung cấp";
            // 
            // txtMaNCC
            // 
            this.txtMaNCC.Location = new System.Drawing.Point(40, 82);
            this.txtMaNCC.Name = "txtMaNCC";
            this.txtMaNCC.Size = new System.Drawing.Size(126, 26);
            this.txtMaNCC.TabIndex = 2;
            // 
            // lbMaNCC
            // 
            this.lbMaNCC.AutoSize = true;
            this.lbMaNCC.Location = new System.Drawing.Point(38, 45);
            this.lbMaNCC.Name = "lbMaNCC";
            this.lbMaNCC.Size = new System.Drawing.Size(133, 20);
            this.lbMaNCC.TabIndex = 1;
            this.lbMaNCC.Text = "Mã Nhà cung cấp";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.bnSave);
            this.panel2.Controls.Add(this.bnCancel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 349);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 100);
            this.panel2.TabIndex = 0;
            // 
            // bnSave
            // 
            this.bnSave.BackColor = System.Drawing.Color.ForestGreen;
            this.bnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bnSave.Location = new System.Drawing.Point(232, 37);
            this.bnSave.Name = "bnSave";
            this.bnSave.Size = new System.Drawing.Size(92, 32);
            this.bnSave.TabIndex = 5;
            this.bnSave.Text = "Save";
            this.bnSave.UseVisualStyleBackColor = false;
            this.bnSave.Click += new System.EventHandler(this.bnSave_Click);
            // 
            // bnCancel
            // 
            this.bnCancel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.bnCancel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bnCancel.Location = new System.Drawing.Point(40, 37);
            this.bnCancel.Name = "bnCancel";
            this.bnCancel.Size = new System.Drawing.Size(92, 32);
            this.bnCancel.TabIndex = 4;
            this.bnCancel.Text = "Cancel";
            this.bnCancel.UseVisualStyleBackColor = false;
            this.bnCancel.Click += new System.EventHandler(this.bnCancel_Click);
            // 
            // frmEditNCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 449);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmEditNCC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sửa thông tin nhà cung cấp";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lbDiaChi;
        private System.Windows.Forms.TextBox txtTenNGH;
        private System.Windows.Forms.Label lbTenNGH;
        private System.Windows.Forms.TextBox txtTenNCC;
        private System.Windows.Forms.Label lbMaThue;
        private System.Windows.Forms.TextBox txtMaThue;
        private System.Windows.Forms.TextBox txtSTK;
        private System.Windows.Forms.Label lbSTK;
        private System.Windows.Forms.Label lbTenNCC;
        private System.Windows.Forms.TextBox txtMaNCC;
        private System.Windows.Forms.Label lbMaNCC;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bnSave;
        private System.Windows.Forms.Button bnCancel;
    }
}